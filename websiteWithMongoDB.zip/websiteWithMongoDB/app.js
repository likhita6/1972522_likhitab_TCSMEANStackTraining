let app = require("express")();
let bodyParser = require("body-parser");
let mongoose = require("mongoose");
mongoose.Promise = global.Promise;
let port = 9090;
let url = "mongodb://localhost:27017/meanstack";
let db = mongoose.connection; 
app.use(bodyParser.urlencoded({extended: true}));    
db.on("error", (err) => console.log(err));  

const mongoDBOption = {
    useNewUrlParser: true,
    useUnifiedTopology: true
}

mongoose.connect(url, mongoDBOption);  

let courseSchema = mongoose.Schema({
    _id:Number,
    course:String,
    description:String,
    amount:Number
})
let Course = mongoose.model("", courseSchema, "Courses");   


app.get("/", (req, res) => {
   
    res.sendFile(__dirname+"/index.html");
});


app.get("/addCourse", (req, res) => {
   
    res.sendFile(__dirname+"/addCourse.html");
});


app.get("/updateCourse", (req, res) => {
    
    res.sendFile(__dirname+"/updateCourse.html");
});


app.get("/deleteCourse", (req, res) => {
   
    res.sendFile(__dirname+"/deleteCourse.html");
});


app.get("/fetchCourse", (req, res) => {
    

    Course.find({}, (error, result) => {
        if (!error) {
            let display = `
            <table ">
            <tr>
                <th>Course ID</th>
                <th> Name</th>
                <th> Description</th>
                <th>Amount</th>
            </tr>`

            for (course in result){
                display += `
                <tr>
                    <th >${result[course]._id}</th>
                    <th >${result[course].course}</th>
                    <th >${result[course].description}</th>
                    <th >${result[course].amount}</th>
                </tr>`
            }
            res.write(display);
            res.write(`</table>`);
            res.end();
        }
    })
})

app.post("/add", (req, res) => {
    let id = req.body.id;
    let name = req.body.title;
    let desc = req.body.desc;
    let price = req.body.price;

    
    let newCourse = new Course({_id:id, course:name, description:desc, amount:price})
    newCourse.save((error, result) => {
        if (!error) {
            
            console.log("course added");
        } else {
           
            console.log("Error");
        }
        res.sendFile(__dirname+"/addCourse.html");
    })
})


app.post("/update", (req, res) => {
    let id = req.body.id;
    let price = req.body.price;

    Course.updateOne({_id: id}, {$set:{amount:price}}, (error, result) => {
        if (!error) {
            if (result.nModified > 0 ) {
                 
                console.log("updated.")
            } else {  
                console.log("Error")
            }

        }
        res.sendFile(__dirname+"/updateCourse.html");
    })
})


app.post("/delete", (req, res) => {
    let id = req.body.id;

    Course.deleteOne({_id:id}, (error, result) => {
        if (!error) {
            if (result.deletedCount > 0 ) {
                res.end();
               
                console.log("deleted.");
            } else {
                
                console.log("error");
            } 
        } else {
            console.log("error");
        }
        res.sendFile(__dirname+"/deleteCourse.html");
    })
})

app.listen(port, () => console.log(`Server running on port ${port}`));