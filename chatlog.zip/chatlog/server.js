let app = require("express")();
let http = require("http").Server(app);  
let io = require("socket.io")(http);

app.get("/",(req,res)=> {
    res.sendFile(__dirname+"/index.html");
})

io.on("connection",(socket)=> {
    
    socket.on("chat",(msg)=> {
        let mongoClient = require("mongodb").MongoClient;
        let url = "mongodb://localhost:27017"

        mongoClient.connect(url, { useUnifiedTopology: true }, (error, client) => {
            if (!error) {
                let db = client.db("meanstack");
                db.collection("chatlog").insertOne({Name: msg.Name, Message: msg.Message}, (error1, result) => {
                    if (!error1) {
                        console.log("received in mongodb cmd");
                    } else {
                        console.log(error2);
                    }
                    client.close();
                });
        
            }
        });
    })
})
http.listen(9090,()=>console.log('server running on port number 9090'));

