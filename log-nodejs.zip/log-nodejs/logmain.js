let obj = require("./loginfo");
obj.input();
