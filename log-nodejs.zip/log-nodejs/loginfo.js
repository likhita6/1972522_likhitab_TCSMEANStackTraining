let obj = require("readline-sync");
let fs = require("fs");

module.exports.input = function () {
  let fname = obj.question("Enter First Name ");
  console.log("You First Name is " + fname);
  debugger;
  let lname = obj.question("Enter Last name ");
  console.log("You Last name is " + lname);
  debugger;
  let gender = obj.question("Enter gender ");
  console.log("You gender is " + gender);
  debugger;
  let occupation = obj.question("Enter occupation ");
  console.log("You salary is " + occupation);
  debugger;

  let jsonArray = new Array();
  let data = fs.readFileSync("log.json");
  if (data.toString()) {
    jsonArray = JSON.parse(data.toString());
  }

  let currentDate = new Date();
  let date =  currentDate.getDate() + "/" +(currentDate.getMonth() + 1) + "/" +   currentDate.getFullYear() + " Time : " +  currentDate.getHours() +":" +  currentDate.getMinutes() + ":" + currentDate.getSeconds();

  let jsonObj = {
    fname,
    lname,
    gender,
    occupation,
    date,
  };
  jsonArray.push(jsonObj);

  let jsonString = JSON.stringify(jsonArray);
  fs.writeFileSync("log.json", jsonString);
  console.log("Updated the file");
  debugger;
};
